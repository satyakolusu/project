package com.klef.jfsd.exam;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ClientDemo {
    public static void main(String[] args) {
        // Load Spring Context
        ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);

        // Get Employee Bean
        Employee employee = context.getBean(Employee.class);
        System.out.println("Employee Details: " + employee);

        // Get Course Bean
        Course course = context.getBean(Course.class);
        System.out.println("Course Details: " + course);
    }
}
