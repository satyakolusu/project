package com.klef.jfsd.exam;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.Arrays;

@Configuration
public class ApplicationConfig {

    @Bean
    public Employee employee() {
        return new Employee(101, "Harsha", 75000.0, "IT", Arrays.asList("Java", "Spring", "Hibernate"));
    }

    @Bean
    public Instructor instructor() {
        Instructor instructor = new Instructor();
        instructor.setInstructorId(201);
        instructor.setName("Dr. Smith");
        instructor.setEmail("smith@example.com");
        instructor.setPhoneNumber("9876543210");
        return instructor;
    }

    @Bean
    public Course course(Instructor instructor) {
        Course course = new Course();
        course.setCourseId(301);
        course.setCourseName("Spring Framework");
        course.setCredits(4);
        course.setInstructor(instructor);
        return course;
    }
}
