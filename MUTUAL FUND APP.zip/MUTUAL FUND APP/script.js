function toggleForm() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    loginForm.style.display = loginForm.style.display === 'none' ? 'block' : 'none';
    signupForm.style.display = signupForm.style.display === 'none' ? 'block' : 'none';
  }
  
  function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    // Placeholder logic for login
    if (username && password) {
      alert(`Logged in as ${username}`);
      // Redirect to respective dashboard based on role
    } else {
      alert("Please enter both username and password.");
    }
  }
  
  function signup() {
    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;
    const email = document.getElementById('email').value;
    const role = document.getElementById('role').value;
    // Placeholder logic for sign up
    if (username && password && email) {
      alert(`Signed up as ${username} (${role})`);
      // Temporary user storage in localStorage or sessionStorage
      localStorage.setItem('user', JSON.stringify({ username, password, email, role }));
      toggleForm(); // Switch back to login
    } else {
      alert("Please fill out all fields.");
    }
  }
  